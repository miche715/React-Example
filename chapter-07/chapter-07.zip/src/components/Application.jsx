import React from "react";
import Accommodate from "./Accommodate";

function Application()
{
    return (
        <div>
            <Accommodate />
        </div>
    );
}

export default Application